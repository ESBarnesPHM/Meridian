# Meridian EMR Simulation Platform

A fictional, static EMR-style simulation platform for pediatric patient safety education.

## Quick start
Open `index.html` in a browser.

## GitHub Pages upload
1. Create a new GitHub repository named `meridian-emr`.
2. Upload **all files and folders inside this folder** to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. GitHub will publish a URL like `https://YOUR-USERNAME.github.io/meridian-emr/`.

## Facilitator workflow
Use the launch page or direct phase links:
- `index.html?case=osteomyelitis-mason&phase=1`
- `index.html?case=osteomyelitis-mason&phase=2`
- `index.html?case=osteomyelitis-mason&phase=3`
- `index.html?case=osteomyelitis-mason&phase=4`
- `index.html?case=osteomyelitis-mason&phase=5`

Phase 4 has a facilitator-controlled reveal. On the Handoff tab, enter code: `IPASS`.

## Future cases
The interface lives in `assets/`. Case content lives in `cases/<case-id>/data.js`. To build a new case, copy the case folder and edit the data file.

## Disclaimer
This is a fictional EMR for simulation/education. It contains no real patient data and is not associated with any clinical software vendor.
